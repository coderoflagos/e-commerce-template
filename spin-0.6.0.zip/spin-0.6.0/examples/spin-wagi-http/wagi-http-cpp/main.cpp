#include<iostream>

int main() {
    std::cout << "Content-Type: application/text\n\nHello, Fermyon!\n" << std::endl;
    return 0;

}
