# Extending Spin with a trigger and application

<https://spin.fermyon.dev/extending-and-embedding>
