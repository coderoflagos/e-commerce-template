# Integration test

## Dependencies

Please add following dependencies to your PATH before running `make test-integration`.

* [bindle-server](https://github.com/deislabs/bindle)
* [nomad](https://github.com/hashicorp/nomad)
* [Hippo.Web](https://github.com/deislabs/hippo)
