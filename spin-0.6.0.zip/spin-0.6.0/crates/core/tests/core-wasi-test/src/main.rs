//! This test program takes argument(s) that determine which WASI feature to
//! exercise and returns an exit code of 0 for success, 1 for WASI interface
//! failure (which is sometimes expected in a test), and some other code on
//! invalid argument(s).

#[link(wasm_import_module = "multiplier")]
extern "C" {
    fn multiply(n: i32) -> i32;
}

type Result = std::result::Result<(), Box<dyn std::error::Error>>;

fn main() -> Result {
    let mut args = std::env::args();
    let cmd = args.next().expect("cmd");
    match cmd.as_str() {
        "noop" => (),
        "echo" => {
            eprintln!("echo");
            std::io::copy(&mut std::io::stdin(), &mut std::io::stdout())?;
        }
        "alloc" => {
            let size: usize = args.next().expect("size").parse().expect("size");
            eprintln!("alloc {size}");
            let layout = std::alloc::Layout::from_size_align(size, 8).expect("layout");
            unsafe {
                let p = std::alloc::alloc(layout);
                if p.is_null() {
                    return Err("allocation failed".into());
                }
                // Force allocation to actually happen
                p.read_volatile();
            }
        }
        "read" => {
            let path = args.next().expect("path");
            eprintln!("read {path}");
            std::fs::read(path)?;
        }
        "write" => {
            let path = args.next().expect("path");
            eprintln!("write {path}");
            std::fs::write(path, "content")?;
        }
        "multiply" => {
            let input: i32 = args.next().expect("input").parse().expect("i32");
            eprintln!("multiply {input}");
            let output = unsafe { multiply(input) };
            println!("{output}");
        }
        "panic" => {
            eprintln!("panic");
            panic!("intentional panic");
        }
        cmd => panic!("unknown cmd {cmd}"),
    };
    Ok(())
}
