# CONTRIBUTING

[https://spin.fermyon.dev/contributing/](https://spin.fermyon.dev/contributing/)
