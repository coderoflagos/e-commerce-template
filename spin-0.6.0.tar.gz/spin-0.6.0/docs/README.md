# The Spin documentation website

**The Spin documentation website is deprecated.** We still run it, but only to redirect to new documentation.

To build and run the Spin documentation website:

1. Build Spin using the [contributing guide](./content/contributing.md).

2. Run the following npm commands:

```
$ npm install
$ npm run spin
```

3. View documentation website at http://localhost:3000
