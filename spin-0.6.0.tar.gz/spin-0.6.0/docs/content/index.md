title = "Introducing Spin"
template = "main"
date = "2022-03-14T00:22:56Z"
[extra]
url = "https://github.com/fermyon/spin/blob/main/docs/content/index.md"

---

The documentation on this site has been moved to [The Fermyon Developer Home](https://developer.fermyon.com).
