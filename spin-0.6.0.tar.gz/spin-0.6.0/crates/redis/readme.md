# Redis trigger for the Spin runtime
